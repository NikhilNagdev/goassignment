package main

import (
	"fmt"
	"goassignment/io"
	"goassignment/parser"
)

func main() {
	records := io.GetRecordsFromCSVReader(io.ReadCSVFile("userrecords/user_records.csv"))
	io.WriteToJsonFile(parser.GetJsonFromRecordObjects(parser.GetRecordObjectsFromCSVReader(records)))

	var mymap = map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}
	_, v := mymap[90]
	if !v {
		fmt.Println("Present")
	}else {
		fmt.Println("Not")
	}
}
