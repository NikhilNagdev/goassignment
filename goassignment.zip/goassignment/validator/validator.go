package validator

import (
	"fmt"
	"log"
	"os"
)

func ValidatePhoneNo(csvRecords []string) bool{
	noOfDigits := len(csvRecords[3])
	if noOfDigits == 10 {
		return true
	}else{
		file, err := os.OpenFile("info.log", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println(err)
			log.Fatal(err)
		}
		defer file.Close()
		log.SetOutput(file)
		log.Println("Phone number should be 10 digits")
		return false
	}
}
func ValidateName(csvRecords []string) bool{
	if csvRecords[1] == "" {
		file, err := os.OpenFile("info.log", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println(err)
			log.Fatal(err)
		}
		defer file.Close()
		log.SetOutput(file)
		log.Println("Name cannot be empty")
		return false
	}
	return true

}

func ValidateEmail(csvRecords []string) bool{
	if csvRecords[2] == ""{
		file, err := os.OpenFile("info.log", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Println(err)
			log.Fatal(err)
		}
		defer file.Close()
		log.SetOutput(file)
		log.Println("Email cannot be empty")
		return false
	}
	return true

}


