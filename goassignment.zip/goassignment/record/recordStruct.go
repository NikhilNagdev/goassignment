package record

import (
	"goassignment/validator"
	"github.com/satori/go.uuid"
)

type Record struct {
	Id string
	Name string
	Email string
	Phone int
	IsActive bool
}

var recordMap map[string]Record

func IsRecordUnique()  {

}

func ValidatePhoneNo(csvRecords []string) bool {
	return validator.ValidatePhoneNo(csvRecords)
}

func ValidateName(csvRecords []string) bool {
	return validator.ValidateName(csvRecords)
}

func ValidateEmail(csvRecords []string) bool {
	return validator.ValidateEmail(csvRecords)
}

func (record Record) IsRecordCorrect(csvRecords []string) bool{
	_, v := recordMap[csvRecords[0]]
	if !v{
		myuuid, _ := go_uuid.NewV4()
		recordMap[myuuid] = record
	}
	return ValidatePhoneNo(csvRecords) && ValidateName(csvRecords) && ValidateEmail(csvRecords)
}

